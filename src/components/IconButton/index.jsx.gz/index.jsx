import React from 'react';

const IconButton = ({imageSrc, imageHeight = 15, imageWidth = 15, altText, handleClick}) => {
  return (
    <button className="icon-button" onClick={handleClick}>
      <img src={imageSrc} height={imageHeight} width={imageWidth} alt={altText} />
    </button>
  )
}

export default IconButton;