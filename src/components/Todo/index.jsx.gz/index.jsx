import React, { useState } from 'react';

import IconButton from "../IconButton";

const Todo = ({ index, title, saveTodo, removeTodo}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [newTitle, setNewTitle] = useState(title);

  const handleChange = (e) => {
    setNewTitle(e.target.value);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    saveTodo(index, newTitle);
    setIsEditing(false);
    setNewTitle('');
  }

  return ( 
    <li className="bg-accent text-dark">
      {isEditing && 
        <form onSubmit={handleSubmit}>
          <input type="text" defaultValue={title} onChange={handleChange} />
          <button type="submit">Save</button>
        </form>
      }
      {!isEditing && <div className="flex justify-between">
        {title}
        <div className="flex" style={{'--gap': 0}}>
          <IconButton imageSrc="/edit.svg" alt="Edit this todo" handleClick={() => setIsEditing(true)} />
          <IconButton imageSrc="/trash.svg" alt="Delete this todo" handleClick={() => removeTodo(index)} />
        </div>  
      </div>}
    </li>
  )
}

export default Todo;