import React from 'react';

const SuperCenter = ({children}) => {
  return (
    <div className="super-center">
      {children}
    </div>
  )
}

export default SuperCenter;