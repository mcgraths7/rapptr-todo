import { useCallback, useState, useEffect } from "react"

const useLocalStorage = (key, defaultValue) => {
  const thatWindow = typeof window !== 'undefined' ? window : undefined;
  const [value, setValue] = useState(() => {
    const jsonValue = thatWindow?.localStorage.getItem(key)
    if (jsonValue != null && typeof jsonValue !== 'undefined') return JSON.parse(jsonValue)
    if (typeof defaultValue === "function") {
      return defaultValue()
    } else {
      return defaultValue
    }
  })

  useEffect(() => {
    if (value === undefined) return thatWindow?.localStorage.removeItem(key)
    thatWindow?.localStorage.setItem(key, JSON.stringify(value))
  }, [key, value, thatWindow])

  const remove = useCallback(() => {
    setValue(undefined)
  }, [])

  return [value, setValue, remove]
}

export default useLocalStorage;