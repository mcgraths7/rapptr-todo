import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import SuperCenter from "../../components/SuperCenter";


// https://www.w3resource.com/javascript/form/email-validation.php
const validateEmail = (email) => {
  if (/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
    return (true)
  }
  return false
}

const LoginPage = () => {
  const navigate = useNavigate();
  const [formValues, setFormValues] = useState({ email: '', password: '' });
  const [emailError, setEmailError] = useState('')
  const [passwordError, setPasswordError] = useState('')

  const [formValid, setFormValid] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);

  const [responseData, setResponseData] = useState({ code: '', message: '', data: {} })

  const handleSubmit = async (event) => {
    event.preventDefault();
    setIsSubmitting(true);
    // Not entirely sure what the issue is, but everything I try returns with a 400 bad request
    try {
      const response = await fetch('http://dev.rapptrlabs.com/Tests/scripts/user-login.php', {
        method: 'POST',
        headers: {
          'content-type': 'application/json'
        },
        body: JSON.stringify({
          email: 'test@rapptrlabs.com',
          password: 'Test123',
        }),
      })
      const r = await response.json();
      setResponseData(r)
    } catch (e) {
      console.error('Failed to fetch', e)
    } finally {
      setIsSubmitting(false);
      navigate('/list');
    }
    // check for errors later
    
  }

  const handleChange = (event) => {
    if (event.target.name === 'email') {
      if (event.target.value && !validateEmail(event.target.value)) {
        setEmailError('Invalid email, please check')
      } else {
        setEmailError('')
      }
    }

    if (event.target.name === 'password') {
      if (event.target.value && event.target.value.length < 4) {
        setPasswordError('Password must be at least 4 characters');
      } else if (event.target.value && event.target.value.length > 16) {
        setPasswordError('Password must be shorter than 16 characters');
      } else {
        setPasswordError('');
      }
    }

    setFormValues({ ...formValues, [event.target.name]: event.target.value })
  }

  useEffect(() => {
    if (!emailError && !passwordError && !isSubmitting && formValues['email'] && formValues['password']) setFormValid(true);
  }, [emailError, passwordError, isSubmitting, formValues])

  return (
    <SuperCenter>
      <h1 className="fs-700">Rapptr Labs</h1>
      <form className="flex flex-col justify-left form-container" onSubmit={handleSubmit}>
        <fieldset className="flex flex-col fb-100" style={{ position: 'relative' }}>
          <label className="fs-500">Email</label>
          <div className="flex">
            <img src="/user.svg" alt="User" width="20" height="20" style={{ position: 'absolute', marginTop: '5px', marginLeft: '4px' }} />
            <input className="icon-input fb-100" type="string" placeholder="test@rapptrlabs.com" name="email" onChange={handleChange} style={{ border: emailError ? '1px solid hsl(var(--color-error))' : 'none' }} />
          </div>
          <p className="fs-300 text-error" style={{ visibility: !!emailError ? 'visible' : 'hidden' }}>{emailError}</p>
        </fieldset>
        <fieldset className="flex flex-col fb-100">
          <label className="fs-500">Password</label>
          <div className="flex">
            <img src="/lock.svg" alt="User" width="20" height="20" style={{ position: 'absolute', marginTop: '5px', marginLeft: '4px' }} />
            <input className="icon-input fb-100" type="password" placeholder="Must be at least 4 characters" name="password" onChange={handleChange} style={{ border: passwordError ? '1px solid hsl(var(--color-error))' : 'none' }} />
          </div>
          <p className="fs-300 text-error" style={{ visibility: !!passwordError ? 'visible' : 'hidden' }}>{passwordError}</p>
        </fieldset>
        {/* Disabled if error or if not both inputs are populated, or if submission in progress */}
        <button type="submit" className="fb-100" disabled={!formValid}>{isSubmitting ? 'Submitting...' : 'Submit'}</button>
        <p className="fs-300 text-error" style={{ visibility: responseData.code === 'Error' ? 'visible' : 'hidden' }}>{responseData.message}</p>
      </form>
    </SuperCenter>
  )
}

export default LoginPage;