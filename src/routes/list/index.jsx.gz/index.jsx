import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'

import SuperCenter from "../../components/SuperCenter";
import Todo from "../../components/Todo";
import useLocalStorage from '../../util/hooks/use-storage';

const ListPage = () => {
  const navigate = useNavigate();

  const [localTodos, setLocalTodos] = useLocalStorage('todos', JSON.stringify([]));
  const [todos, setTodos] = useState(JSON.parse(localTodos));
  const [todo, setTodo] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [search, setSearch] = useState('');

  const clearInput = () => {
    const input = document.querySelector('#new-todo');
    input.value = '';
    setTodo('');
  }

  const handleChange = (e) => {
    setTodo(e.target.value)
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setTodos([...todos, todo]);
    clearInput();
    setIsCreating(false);
  }

  const saveTodo = (index, newTitle) => {
    const localTodos = todos;
    localTodos[index] = newTitle;
    setTodos([...localTodos]);
  }

  const removeTodo = (index) => {
    const newTodos = todos.filter((_, idx) => index !== idx);
    setTodos(newTodos);
  }

  useEffect(() => {
    setLocalTodos(JSON.stringify(todos));
  }, [todos, setLocalTodos])

  return (
    <SuperCenter>
      <button className="top-right" onClick={() => navigate('/')}>Logout</button>
      <div className="container flow">
        <h1>My Todo List</h1>
        <div className="flex">
          {!isCreating && <input type="text" placeholder="Search for a todo..." onChange={(e) => setSearch(e.target.value)} />}
          {!isCreating && <button onClick={() => setIsCreating(true)}>New</button>}
        </div>
        {isCreating && <form className="flex" onSubmit={handleSubmit}>
          <input onChange={handleChange} type="text" id="new-todo" />
          <button type="submit">Save</button>
        </form>}
        <ul className="todo-list flex flex-col">
          {todos.filter((td) => td.includes(search)).map((td, index) => <Todo key={`todo-${index}`} index={index} title={td} removeTodo={removeTodo} saveTodo={saveTodo}/>)}
        </ul>
      </div>
    </SuperCenter>
  )
}

export default ListPage;