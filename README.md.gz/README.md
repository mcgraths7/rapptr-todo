# Rapptr Labs Submission

## Technology / Tools Used

1. React (via create-react-app)
2. Custom design system (including a slightly modified but otherwise industry standard CSS reset)
3. A custom react hook for interfacing with local storage
4. React Router

## How to use

1. npm install
2. npm run start
3. Enter email and password (any will work, using the test credentials hardcoded behind the scenes)
4. Be taken to list page
5. Basic CRUD operations are available, along with rudimentary search
6. Persists to local storage
7. Logout button takes you back to login page

## Some notes

1. I did not spend a lot of time on the CSS outside of the existing styles from my design system. I think it looks pretty clean, but did not want to go overboard on this

2. I was not able to get the API request to work. I tried in Postman, client side (cors error), and a nodejs file which I called from the browser. I left the browser request in
